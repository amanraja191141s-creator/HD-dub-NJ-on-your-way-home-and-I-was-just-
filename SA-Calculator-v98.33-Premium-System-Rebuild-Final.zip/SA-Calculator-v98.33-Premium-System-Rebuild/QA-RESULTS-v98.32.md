# QA Results — SA Calculator v98.32

## Source-level verification

- `npm test`: **248 passed, 0 failed, 0 skipped**.
- `node --check assets/js/app.js`: passed.
- `npm run build:web`: passed; 11 required runtime assets verified and copied.
- New stylesheet copied byte-identically into `www/assets/css/rebuild-v98.32.css`.
- Android workflow copies are byte-identical.
- YAML parsed successfully with PyYAML.
- ZIP archive integrity checked after packaging.
- Currency catalogue: 105 unique selectable ISO currency codes; explicit display names and representative flag map retained.

## New regression coverage

- No dedicated currency modal or `openCurrencyPicker` runtime remains.
- Unified picker has search, flag, localized name, ISO code, region and selected-state handling.
- Native select surface is hidden after custom enhancement.
- Pseudo toolbars and decorative header fragments are disabled.
- Duplicate drawer pseudo-icon column is disabled.
- Body Metrics empty status is hidden and empty result is neutral.
- Fuel Efficiency empty/incomplete/error/success states are tested.
- Tool keypad remains on-demand; Calculator keypad remains permanent.
- Package, manifest, app runtime, service worker and workflow identities match.

## Not physically certified

- APK has not been installed on the user's phone in this run.
- Android WebView keyboard/IME behavior, screenshot parity, live currency providers, FPS/jank, memory, battery, ANR and long-session stability remain device-level verification tasks.
- Automated source tests do not prove universal zero bugs or zero lag.
